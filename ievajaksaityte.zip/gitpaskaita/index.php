<?php
/**
 * Created by PhpStorm.
 * User: ieva
 * Date: 16.3.17
 * Time: 17.56
 */

echo 'text edited in branch';
echo 'more text';