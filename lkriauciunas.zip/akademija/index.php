<?php
/**
 * Created by PhpStorm.
 * User: lukas
 * Date: 16.3.17
 * Time: 20.03
 */

echo "Zdarof Lithuania!";
