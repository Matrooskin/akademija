<?php
/**
 * Created by PhpStorm.
 * User: lukas
 * Date: 16.3.17
 * Time: 20.03
 */

for ($i = 0; $i < 100; $i++) {
    if ($i % 3 == 0) {
        echo 'Fizzen';
    } else if ($i % 5 == 0) {
        echo 'Buzzen';
    } else if ($i % 15 == 0) {
        echo 'FizzBuzzen';
    } else {
        echo $i;
    }
}
