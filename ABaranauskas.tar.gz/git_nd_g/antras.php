<?php
/**
 * Created by PhpStorm.
 * User: aivaras
 * Date: 16.3.19
 * Time: 14.13
 */
    echo "Antras failas";
    echo "Antro failo redagavimas is FT01";
    echo "Antro failo redagavimas is master";
?>