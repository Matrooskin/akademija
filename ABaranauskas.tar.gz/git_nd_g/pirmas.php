<?php
/**
 * Created by PhpStorm.
 * User: aivaras
 * Date: 16.3.19
 * Time: 14.12
 */
    echo "Pirmas failas";
    echo "Pirmo failo redagavimas is FT01";
    echo "Pirmo failo redagavimas is master.";
    echo "Pirmo failo antras redagavimas is master";
?>