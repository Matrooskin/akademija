<?php
/**
 * Created by PhpStorm.
 * User: darius0021
 * Date: 16.3.20
 * Time: 14.50
 */
echo "Message us on facebook!";
echo "<br>Or send us email: pamparam@gmail.com";
echo "This is the second page!";