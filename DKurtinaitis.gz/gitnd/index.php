<?php
/**
 * Created by PhpStorm.
 * User: darius0021
 * Date: 16.3.20
 * Time: 14.46
 */
echo "Hello world!";
echo "This page is very special page, plus it is the first one!";
echo 'Editing my first page!';