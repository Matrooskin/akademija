<?php
//komentaras
//dar vienas komentaras

echo 'kas cia?';
echo 'kazkoks kodas turbut';
echo 'dar daugiau kodo';

?>
