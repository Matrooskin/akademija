<?php

echo 'o man patinka kitaip sita eilute';
echo 'pridesime truputi kodo';

?>
