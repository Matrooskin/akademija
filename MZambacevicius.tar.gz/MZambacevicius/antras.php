<?php

echo "as antras";
echo "paredaguota";
echo "dar karta paredaguota";