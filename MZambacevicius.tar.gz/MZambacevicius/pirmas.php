<?php

echo "as pirmas redaguota konfliktui";
echo "conflict";
echo "paredaguota";
echo "dar karta redaguota";