<?php
/**
 * Created by PhpStorm.
 * User: julius
 * Date: 16.3.19
 * Time: 15.01
 */
    // 3 punktas
    $name = 'Julius';
    echo 'Hello ' . $name;

    // 6 punktas ir 13 punktas
    echo '. Aš mokinuosi Git. Konflikto sukūrimas ir išsprendimas.';

    // 16 punktas
    echo ' ' . $name . ' namų darbai.';