<?php
/**
 * Created by PhpStorm.
 * User: julius
 * Date: 16.3.19
 * Time: 15.01
 */
    // 3 punktas
    $num1 = 1;
    $num2 = 2;
    $atsakymas = $num1 + $num2;
    echo $atsakymas;

    // 8 punktas
    echo ' = ' . $num1 . ' + ' . $num2;

    // 11 punktas
    $num1 = 2;
    $num2 = 3;
