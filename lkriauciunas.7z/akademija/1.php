<?php

echo 'Sveikas pasauli';
