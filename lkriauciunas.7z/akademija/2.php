<?php

for ($i = 0; $i < 100; $i++) {
    if ($i % 3 == 0) {
        echo 'Fizze';
    } else if ($i % 5 == 0) {
        echo 'Buzze';
    } else if ($i % 15 == 0) {
        echo 'FizzBuzze';
    } else {
        echo $i;
    }
}
