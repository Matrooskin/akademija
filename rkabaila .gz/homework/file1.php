<?php
/**
 * Created by PhpStorm.
 * User: rimas
 * Date: 3/18/16
 * Time: 2:31 PM
 */
echo 'Hello. This is file1';
echo 'Modified line on feature';
echo 'Added line on master';