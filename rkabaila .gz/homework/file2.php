<?php
/**
 * Created by PhpStorm.
 * User: rimas
 * Date: 3/18/16
 * Time: 2:32 PM
 */
echo 'Hello. This is file2';
echo 'Added line';
echo 'Added one more line';