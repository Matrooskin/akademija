<?php
/**
 * Created by PhpStorm.
 * User: mindaugas
 * Date: 16.3.20
 * Time: 18.33
 */

echo "Pirmasis failas ir tos pacios eilutes redagavimas.";
echo "Antra eilute.";
echo "Vel redaguoji si faila ir darau 16 punkta.";
