<?php
/**
 * Created by PhpStorm.
 * User: mindaugas
 * Date: 16.3.20
 * Time: 18.34
 */

echo "Antras failas";
echo "Antra eilute antrame faile.";
echo "Dar vienas antro failo redagavimas.";