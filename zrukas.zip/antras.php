<?php

// komentaras

echo 'keiciame eilute';
echo 'dar viena pakeista eilute';

?>

