<?php

echo 'man patinka sita eilute kitaip uzrasyta';

?>

