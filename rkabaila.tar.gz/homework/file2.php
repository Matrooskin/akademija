<?php
/**
 * Created by PhpStorm.
 * User: rimas
 * Date: 3/19/16
 * Time: 7:03 PM
 */
echo 'Hello. This is file2';
echo 'Added new line';
echo 'Added one more line';
