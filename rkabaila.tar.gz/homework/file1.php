<?php
/**
 * Created by PhpStorm.
 * User: rimas
 * Date: 3/19/16
 * Time: 7:02 PM
 */
echo 'Hello. This is file1';
echo 'Added new line in file1';
echo 'Added one more line';
