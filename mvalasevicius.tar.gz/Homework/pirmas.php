<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 16.3.19
 * Time: 11.45
 */

echo 'pirmas failas echo pakeistas ir vėl pakeistasa';
