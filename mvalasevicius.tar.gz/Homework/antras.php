<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 16.3.19
 * Time: 11.46
 */

echo 'antro failo echo 11 uzd redagavimas';