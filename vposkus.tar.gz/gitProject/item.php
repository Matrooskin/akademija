<?php
$itemId=1;
$itemName='Test prekė';
$itemPrihirce=4.2;
$itemsArray=array('First item','Second Item','Third Item');
foreach($itemsArray as $item){
    echo $item;
}

//Get information about Server
print_r($_SERVER);
?>