<?php
    $word='Hello world';
    list($firstWord,$secondWord)=list(' ',$word);
    echo $firstWord.' '.$secondWord;

    //print information about session

    print_r($_SESSION);

?>