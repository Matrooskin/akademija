<?php
/**
 * Created by PhpStorm.
 * User: povilas
 * Date: 16.3.20
 * Time: 09.04
 */
echo "eilutes readagvimas";