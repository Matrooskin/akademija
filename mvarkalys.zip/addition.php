<?php
$a = 1;
$b = 2;
$c = 3;
$d = 4;

echo "a + b + c + d = ".($a + $b + $c + $d);