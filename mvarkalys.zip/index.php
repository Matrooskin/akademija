<?php
echo "Hello world. This is awesome git app. I want to get the best mark doing it.";